package com.liveproject.HibernateToSpring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HibernateToSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
