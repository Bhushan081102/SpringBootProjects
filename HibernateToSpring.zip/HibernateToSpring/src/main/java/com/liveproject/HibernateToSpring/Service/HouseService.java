package com.liveproject.HibernateToSpring.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.liveproject.HibernateToSpring.Dao.HouseDao;
import com.liveproject.HibernateToSpring.Entity.House;

@Service
public class HouseService {
	
	@Autowired
	HouseDao dao;
	
	public House getDataById(int h_id) {
		return dao.getDetailById(h_id);
		
	}
	
	public List<House> getallInfo(){
		return dao.getallInfo();
		
	}
	
	public House addanotherdata(House house) {
		return dao.addAnotherDetails(house);
		
	}
	
	public House UpdateHousedata(House house) {
		return dao.UpdateHouseInfo(house);
		
	}
	
	public House deteInfoById(int h_id) {
		return dao.deleteDetailById(h_id);
		
	}

}
