package com.liveproject.HibernateToSpring.Dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.*;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import com.liveproject.HibernateToSpring.Entity.House;

@Configuration
public class HouseDao {
	
	List<House> list;
	
	@Autowired
	SessionFactory factory;
	
	public House getDetailById(int h_id) {
		Session session=factory.openSession();
		House house=session.load(House.class, h_id);
		return house;
		
	}
	
	public List<House> getallInfo(){
		Session session = factory.openSession();
		String hql = "FROM House";
        Query<House> query = session.createQuery(hql, House.class);
        List<House> house=query.getResultList();
        return house ;
		
	}
	
	public House addAnotherDetails(House house) {
		Session session = factory.openSession();
		//House addhouse=new House("pune", "mumbai");
		session.save(house);
		session.beginTransaction().commit();
		return house;
		
	}
	
	public House UpdateHouseInfo(House house) {
		Session session = factory.openSession();
		session.update(house);
		session.beginTransaction().commit();
		return house;
		
	}
	
	public House deleteDetailById(int h_id) {
		Session session=factory.openSession();
		House house = session.get(House.class, h_id);
        if (house != null) {
            session.delete(house);
        }
        session.beginTransaction().commit();
		return house;
		
	}

}
