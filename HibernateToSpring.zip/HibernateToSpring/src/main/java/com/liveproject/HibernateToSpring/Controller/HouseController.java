package com.liveproject.HibernateToSpring.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.liveproject.HibernateToSpring.Entity.House;
import com.liveproject.HibernateToSpring.Service.HouseService;

@RestController
public class HouseController {

	@Autowired
	HouseService service;
	
	@GetMapping("getallinfo/{h_id}")
	public House getDataById(@PathVariable("h_id") int h_id) {
		return service.getDataById(h_id);
		
	}
	
	@GetMapping("getallinfo")
	public List<House> getAllData(){
		return service.getallInfo();
		
	}
	
	@PostMapping("addanotherinfo")
	public House addanotherdata(@RequestBody House house) {
		return service.addanotherdata(house);
		
	}
	
	@PutMapping("updateinfo")
	public House UpdatehouseInfor(@RequestBody House house) {
		return service.UpdateHousedata(house);
		
	}
	
	@DeleteMapping("deletedata/{h_id}")
	public House deteInfoById(@PathVariable("h_id") int h_id) {
		return service.deteInfoById(h_id);
		
	}
}
