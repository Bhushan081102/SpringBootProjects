package com.liveproject.HibernateToSpring.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class House {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	int h_id;
	String h_name;
	String h_location;
	public House() {
		super();
		// TODO Auto-generated constructor stub
	}
	public House(String h_name, String h_location) {
		super();
		this.h_name = h_name;
		this.h_location = h_location;
	}
	
	
	public House(int h_id, String h_name, String h_location) {
		super();
		this.h_id = h_id;
		this.h_name = h_name;
		this.h_location = h_location;
	}
	public int getH_id() {
		return h_id;
	}
	public void setH_id(int h_id) {
		this.h_id = h_id;
	}
	public String getH_name() {
		return h_name;
	}
	public void setH_name(String h_name) {
		this.h_name = h_name;
	}
	public String getH_location() {
		return h_location;
	}
	public void setH_location(String h_location) {
		this.h_location = h_location;
	}
	@Override
	public String toString() {
		return "House [h_id=" + h_id + ", h_name=" + h_name + ", h_location=" + h_location + "]";
	}
	
	

}
