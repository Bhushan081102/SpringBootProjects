package com.example.SpringBootProjectEx.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.SpringBootProjectEx.Entity.Music;
import com.example.SpringBootProjectEx.Service.MusicServiceInf;

@RestController
public class Controller {

	@Autowired
	MusicServiceInf serviceInf;
	
	@GetMapping("hello")
	public String hello() {
		return "I tried my best sir";
	}
	
	//This is for getting all details of music
	@GetMapping("alldetails")
	public List<Music> getAlldetails(){
		return this.serviceInf.getAllDetails();
	}
	
	//When your id is not same then you need to pass an path variable parameter
	@GetMapping("alldetails/{id}")
	public Music getMusicbyId(@PathVariable("id") int m_id) {
		
		return this.serviceInf.getMusic(m_id);
		
	}
	
	@PostMapping("addmusicdetails")
	public Music addMusicDetails(@RequestBody Music music) {
		
		return this.serviceInf.addCourse(music);
		
	}
	
	@DeleteMapping("deleteData/{id}")
	public Music deletDetailsbyId(@PathVariable("id") int m_id) {
		
		return this.serviceInf.deletMusic(m_id);
		
	}
	
	@PutMapping("updatedata")
	public Music UpdateMusicDetails(@RequestBody Music music) {
		
		return this.serviceInf.updateMusic(music);
		
	}
	
	@PutMapping("updatedata/{id}")
	public Music updatedatabyId(@PathVariable("id") int m_id) {
		return this.serviceInf.updatebyId(m_id);
		
	}
}
