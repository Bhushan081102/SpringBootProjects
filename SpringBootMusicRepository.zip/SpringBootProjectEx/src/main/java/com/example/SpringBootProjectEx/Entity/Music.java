package com.example.SpringBootProjectEx.Entity;

public class Music {

	 int m_id;
	 String m_title;
	 String m_artist;
	 String m_album;
	 String m_language;
	 String m_genre;
	 int m_year; 
	 int m_rating;
	public Music() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Music(int m_id, String m_title, String m_artist, String m_album, String m_language,
			String m_genre, int m_year, int m_rating) {
		super();
		this.m_id = m_id;
		this.m_title = m_title;
		this.m_artist = m_artist;
		this.m_album = m_album;
		this.m_year = m_year;
		this.m_rating = m_rating;
		this.m_language = m_language;
		this.m_genre = m_genre;
	}

	public int getM_id() {
		return m_id;
	}

	public void setM_id(int m_id) {
		this.m_id = m_id;
	}

	public String getM_title() {
		return m_title;
	}

	public void setM_title(String m_title) {
		this.m_title = m_title;
	}

	public String getM_artist() {
		return m_artist;
	}

	public void setM_artist(String m_artist) {
		this.m_artist = m_artist;
	}

	public String getM_album() {
		return m_album;
	}

	public void setM_album(String m_album) {
		this.m_album = m_album;
	}

	public int getM_year() {
		return m_year;
	}

	public void setM_year(int m_year) {
		this.m_year = m_year;
	}

	public int getM_rating() {
		return m_rating;
	}

	public void setM_rating(int m_rating) {
		this.m_rating = m_rating;
	}

	public String getM_language() {
		return m_language;
	}

	public void setM_language(String m_language) {
		this.m_language = m_language;
	}

	public String getM_genre() {
		return m_genre;
	}

	public void setM_genre(String m_genre) {
		this.m_genre = m_genre;
	}

	@Override
	public String toString() {
		return "Music [m_id=" + m_id + ", m_title=" + m_title + ", m_artist=" + m_artist + ", m_album=" + m_album
				+ ", m_year=" + m_year + ", m_rating=" + m_rating + ", m_language=" + m_language + ", m_genre="
				+ m_genre + "]";
	}

	public Music(int m_id, String m_title) {
		super();
		this.m_id = m_id;
		this.m_title = m_title;
	}
	 
	 
	
}
