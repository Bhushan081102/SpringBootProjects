package com.example.SpringBootProjectEx.Service;

import java.util.*;

import org.springframework.stereotype.Service;

import com.example.SpringBootProjectEx.Entity.Music;

//We need to import @Service annotation

@Service
public class MusicService implements MusicServiceInf{

	
	//We need to declare it as global
	 List<Music>list;

		public MusicService() {
			list = new ArrayList<>();
	        list.add(new Music(1, "title1", "artist1", "album1", "language1", "genre1", 2001, 1));
	        list.add(new Music(2, "title2", "artist2", "album2", "language2", "genre2", 2002, 2));
	        list.add(new Music(3, "title3", "artist3", "album3", "language3", "genre3", 2003, 3));
	        list.add(new Music(4, "title4", "artist4", "album4", "language4", "genre4", 2004, 4));
			
	    }
	

		//Post the data
	@Override
	public Music addCourse(Music music) {
		//ArrayList<Music> list=new ArrayList<Music>();
		list.add(music);
		return music;
	}

	@Override
	public List<Music> getAllDetails() {
	//	List<Music> list=new ArrayList<Music>();
		return list;
	}


	@Override
	public Music getMusic(int m_id) {
		//List<Music> list=new ArrayList<Music>();
		Music c=null;
		for(Music music:list) {
			if(music.getM_id()==m_id) {
				c=music;
				break;
			}
		}
		return c;
		
	}


	@Override
	public Music deletMusic(int m_id) {
		Music c=null;
		for (Music music : list) {
			if(music.getM_id()==m_id) {
				c=music;
				break;
			}
		}
		return c;
	}


	@Override
	public Music updateMusic(Music music) {
		list.add(music);
		return music;
	}


	@Override
	public Music updatebyId(int m_id) {
		Music c=null;
		for (Music music : list) {
			if(music.getM_id()==m_id) {
				c=music;
				break;
			}
		}
		return c;
	}

}
