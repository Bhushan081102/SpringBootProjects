package com.example.SpringBootProjectEx.Service;

import java.util.List;

import com.example.SpringBootProjectEx.Entity.Music;


public interface MusicServiceInf {
public List<Music> getAllDetails();
public Music addCourse(Music music);
public Music getMusic(int m_id);
public Music deletMusic(int m_id);
public Music updateMusic(Music music);
public Music updatebyId(int m_id);
}

/*
public Course getCourse(long courseId);
public Course addCourse(Course course);
public Course updateCourse(Course course);
public Course deleteCourse(long courseId);
 * 
 * 
 */
