package com.example.TuneRepositorySpringBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TuneRepositorySpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(TuneRepositorySpringBootApplication.class, args);
	}

}
