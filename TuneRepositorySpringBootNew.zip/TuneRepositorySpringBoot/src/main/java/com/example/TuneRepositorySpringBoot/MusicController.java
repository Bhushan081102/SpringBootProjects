package com.example.TuneRepositorySpringBoot;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.*;

@RestController
public class MusicController {

	@GetMapping("First")
	public String queryCheck() {
		return "This is first Spring Boot Application";
	}

	@GetMapping("alldetails")
	public ArrayList<Music> addMusicDetails() {

		ArrayList<Music> list = new ArrayList<Music>();
		list.add(new Music(1, "Title1", "Artist1", "Album1", 2020));
		list.add(new Music(2, "Title2", "Artist2", "Album2", 2021));
		list.add(new Music(3, "Title3", "Artist3", "Album3", 2022));
		list.add(new Music(4, "Title4", "Artist4", "Album4", 2023));
		return list;
	}

	@PostMapping("alldetails/{byId}")
	public void getMusicDetailsbyId(@PathVariable("byId") int id) {
		System.out.println(id);
		System.err.println("The id is: "+id);
	}

	
	
	
	@PostMapping("addMusicdetails")
	public void addCourse(@RequestBody Music music) {
		System.out.println(music);
	}
	
	
	
	@GetMapping("allartistdetails")
	public ArrayList<Music> getartistdetails(){
		
		ArrayList<ArtistDetails> details=new ArrayList<ArtistDetails>();
		details.add(new ArtistDetails("Arist1"));
		details.add(new ArtistDetails("Arist2"));
		details.add(new ArtistDetails("Arist3"));
		
		Music musics=new Music("title1", "Artist1", "album1", 2020, details);
		
		ArrayList<ArtistDetails> albumtype=new ArrayList<ArtistDetails>();
		albumtype.add(new ArtistDetails("Hindi"));
		albumtype.add(new ArtistDetails("English"));
		albumtype.add(new ArtistDetails("French"));
		
		Music musics1=new Music("title2", "Artist2", "album2", 2020, albumtype);
		
		ArrayList<Music> alldetails=new ArrayList<Music>();
		alldetails.add(musics);
		alldetails.add(musics1);
		return alldetails;
		
	}
	
	


	public ArrayList<Music> getMusicDetailsbyIName() {
		return null;

	}

	public ArrayList<Music> getMusicDetailsbyArtist() {
		return null;

	}

	public ArrayList<Music> getMusicDetailsbyTitle() {
		return null;

	}

	public ArrayList<Music> getMusicDetailsbyAlbum() {
		return null;

	}

	public ArrayList<Music> getMusicDetailsbyReleaseYear() {
		return null;

	}

	public ArrayList<Music> deleteAllMusicDetailsby() {
		return null;

	}

	@DeleteMapping("delete")
	public ArrayList<Music> deleteMusicDetailsbyId() {
		ArrayList<Music> list1 = new ArrayList<Music>();
		list1.add(new Music(1, "Title1", "Artist1", "Album1", 2020));
		return list1;

	}

	public ArrayList<Music> UpdateMusicDetails() {
		return null;

	}
	public ArrayList<Music> UpdateMusicDetailsbyname() {
		return null;

	}
	public ArrayList<Music> UpdateMusicDetailsbyyear() {
		return null;

	}
	public ArrayList<Music> UpdateMusicDetailsbyartist() {
		return null;

	}
}
