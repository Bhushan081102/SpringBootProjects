package com.example.TuneRepositorySpringBoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TuneRepositorySpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
