package com.example.Controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.Entity.Mobile;
import com.example.Service.MobileService;

@RestController
public class MobileController {

	@Autowired
	MobileService service;
	
	@GetMapping("getmobiledetails")
	public List<Mobile>getMobileDetails(){
		return service.getMobileDetails();
		
	}
	
	@PostMapping("addanother")
	public Mobile addAnoterDetail(@RequestBody Mobile mobile){
		return service.addAnoterDetail(mobile);
	}
	
	@PutMapping("update")
	public Mobile updatedetails(@RequestBody Mobile mobile) {
		
		return service.UpdateDetails(mobile);
		
	}
	
	@DeleteMapping("DeleteData")
	public Mobile Deletedata(@RequestBody Mobile mobile) {
		
		return service.Deletedata(mobile);
		
	}
	
	@GetMapping("getmobiledetailsbyId/{m_id}")
	public Mobile getDataById(@PathVariable("m_id") int m_id) {
		return service.getDataById(m_id);
		
	}
	
	@GetMapping("getmobiledetails/{m_name}")
	public Mobile getAllDataByName(@PathVariable("m_name") String m_name) {
		return service.getDataByName(m_name);
		
	}
	
	
	//This is for the jdbc code 
	
	@GetMapping("jdbcdata")
	public ArrayList<Mobile> getdatabyusingjdbc() throws Exception{
		return service.getAlldataByjdbc();
		
	}
}
