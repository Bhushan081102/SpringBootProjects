package com.example.Dao;

import java.util.ArrayList;
import java.util.List;
import java.sql.*;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.example.Entity.Mobile;

//We use both of them 

//@Component
@Repository
public class MobileDao {

	List<Mobile> list;

	public MobileDao() {
		list = new ArrayList<Mobile>();
		list.add(new Mobile(1, "Vivo", "Pune"));
		list.add(new Mobile(2, "Oppo", "Mumbai"));
		list.add(new Mobile(3, "Apple", "delhi"));
		list.add(new Mobile(4, "Realme", "japan"));
	}

//	public Mobile getMobileDetails(){
//	    list=new ArrayList<Mobile>();
//		list.add(new Mobile(1, "Vivo", "Pune"));
//		list.add(new Mobile(2, "Oppo", "Mumbai"));
//		list.add(new Mobile(3, "Apple", "delhi"));
//		list.add(new Mobile(4, "Realme", "japan"));
//		
//		return list;
//	}

	public Mobile addAnotherMobile(Mobile mobile) {
		list.add(mobile);
		return mobile;

	}

	public List<Mobile> getMobileDetails() {
		// TODO Auto-generated method stub
		return list;
	}

	public Mobile UpdateDetails(Mobile mobile) {
		list.add(mobile);
		return mobile;

	}

	public Mobile DeleteDetailsinTable(Mobile mobile) {
		list.add(mobile);
		return mobile;

	}

	public Mobile getDataByUsingId(int m_id) {

		Mobile c = null;
		for (Mobile mobile : list) {
			if (mobile.getM_id() == m_id) {
				c = mobile;
			}
		}
		return c;
	}

	public Mobile getDataByName(String m_name) {
		Mobile c = null;
		for (Mobile mobile : list) {

			if (mobile.getM_name().equals(m_name)) {
				c = mobile;
			}
		}
		return c;

	}

	// This is for JDBC code

	public ArrayList<Mobile> getdatabyusingjdbc() throws Exception {
		ArrayList<Mobile> list = new ArrayList<Mobile>();
		Class.forName("com.mysql.cj.jdbc.Driver");

		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/music_management", "root", "root");
		
		String query = "select * from mobile";
		Statement stm=con.createStatement();
//		PreparedStatement pst = con.prepareStatement(query);
		ResultSet rs=stm.executeQuery(query);
		
		while(rs.next()) {
			
			int id=rs.getInt("m_id");
			String name=rs.getString("m_name");
			String location=rs.getString("m_location");
			
			Mobile mobile=new Mobile(id, name, location);
			list.add(mobile);
						
		}
		return list;

	}
}
