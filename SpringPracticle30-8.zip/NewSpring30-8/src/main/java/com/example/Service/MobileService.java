package com.example.Service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Dao.MobileDao;
import com.example.Entity.Mobile;

@Service
public class MobileService {
	
	@Autowired
	MobileDao dao;

	public List<Mobile> getMobileDetails(){
		return dao.getMobileDetails();
		
	}
	
	public Mobile addAnoterDetail(Mobile mobile){
		return dao.addAnotherMobile(mobile);
	}
	
	public Mobile UpdateDetails(Mobile mobile) {
		return dao.UpdateDetails(mobile);
		
	}
	
	public Mobile Deletedata(Mobile mobile) {
		return dao.DeleteDetailsinTable(mobile);
		
	}
	
	public Mobile getDataById(int m_id) {
		return dao.getDataByUsingId(m_id);
		
	}
	
	public Mobile getDataByName(String m_name) {
		
		return dao.getDataByName(m_name);
		
	}
	
	//This is for jdbc
	
	public ArrayList<Mobile> getAlldataByjdbc() throws Exception{
		return dao.getdatabyusingjdbc();
		
	}
}
