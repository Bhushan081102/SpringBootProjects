package com.example.Entity;

public class Mobile {

	int m_id;
	String m_name;
	String m_location;
	public Mobile() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Mobile(int m_id, String m_name, String m_location) {
		super();
		this.m_id = m_id;
		this.m_name = m_name;
		this.m_location = m_location;
	}
	public int getM_id() {
		return m_id;
	}
	public void setM_id(int m_id) {
		this.m_id = m_id;
	}
	public String getM_name() {
		return m_name;
	}
	public void setM_name(String m_name) {
		this.m_name = m_name;
	}
	public String getM_location() {
		return m_location;
	}
	public void setM_location(String m_location) {
		this.m_location = m_location;
	}
	@Override
	public String toString() {
		return "Mobile [m_id=" + m_id + ", m_name=" + m_name + ", m_location=" + m_location + "]";
	}
	
	
}
