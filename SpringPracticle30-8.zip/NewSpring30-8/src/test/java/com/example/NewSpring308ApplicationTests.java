package com.example;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NewSpring308ApplicationTests {

	@Test
	void contextLoads() {
	}

}
