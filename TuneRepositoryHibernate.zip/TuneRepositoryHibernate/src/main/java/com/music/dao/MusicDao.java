package com.music.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.music.entity.Music;

public class MusicDao {

	// getting all data from database
	public static ArrayList<Music> fetchAllMusicDetails() {
		ArrayList<Music> list = new ArrayList<>();
		Configuration cfg = new Configuration();
		cfg.configure();
		cfg.addAnnotatedClass(Music.class);

		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();

		Criteria criteria = session.createCriteria(Music.class);

		List<Music> list1 = criteria.list();

		for (Music music : list1) {
			System.out.println(music);
		}
		return list;

	}

	// insert data
	public static void insetData(ArrayList<Music> list){

		Configuration cfg = new Configuration();
		cfg.configure();
		cfg.addAnnotatedClass(Music.class);

		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();

		Music music1 = new Music("Hotel California", "Eagles", "Hotel California", 1976);
		Music music2 = new Music("Rolling in the Deep", "adele", "After 21 Hours", 2010);
		Music music3 = new Music("Shape of You", "Ed Sheeran", "Divide", 2017);
		Music music4 = new Music("Uptown Funk", "The Weeknd", "Uptown Special", 2014);
		Music music5 = new Music("Bad Guy", "Billie Eilish", "Bad Guy", 2019);
		
		ArrayList<Music>musiclist=new ArrayList<Music>();
		musiclist.add(music1);
		musiclist.add(music2);
		musiclist.add(music3);
		musiclist.add(music4);
		musiclist.add(music5);
		for (Music allMusic : musiclist) {
			session.save(allMusic);
		}
		
		System.out.println("Data Saved!!!");

		session.beginTransaction().commit();
	}
	
	//Delete data from 
	public static ArrayList<Music> delfetchAllDetails(){
		ArrayList<Music> list=new ArrayList<>();
		Configuration cfg = new Configuration();
		cfg.configure();
		cfg.addAnnotatedClass(Music.class);

		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();
		
		Music music=new Music(6,"Bad Guy", "Billie Eilish", "Bad Guy", 2019);
		session.delete(music);
		System.out.println("Data deleted successfully!!");
		session.beginTransaction().commit();
		return list;
}
	
	//Update data from the database
	public static ArrayList<Music> updateMusicDetails(){
		ArrayList< Music> Update=new ArrayList<Music>();
		Configuration cfg=new Configuration();
		cfg.configure();
		cfg.addAnnotatedClass(Music.class);
		
		SessionFactory factory=cfg.buildSessionFactory();
		Session session=factory.openSession();
		
		Music music=new Music(1, "Bad Guy", "Billie Eilish", "Bad Guy", 2019);
		session.update(music);
		System.out.println("Data Is Updated!!");
		session.beginTransaction().commit();
		
		return Update;
		
	}
}
