package com.music.controller;

import java.util.ArrayList;

import com.music.entity.Music;
import com.music.service.MusicService;

public class MusicController {

	//Select Data From Database
	public static ArrayList<Music> fetchAllMusicDetails() {
		MusicService musicService = new MusicService();
		return musicService.getAllMusicDetails();

	}

	// Delete By using id
	public static ArrayList<Music> delMusicDetailsperId() {
		MusicService musicService = new MusicService();
		return musicService.delAllclassDetails();
	}
	
	//Update All Details
	public static ArrayList<Music> UpdateDataInTable(){
		MusicService musicService=new MusicService();
		ArrayList<Music> list=musicService.UpdateClassDetails();
		return list;
		
	}
}
