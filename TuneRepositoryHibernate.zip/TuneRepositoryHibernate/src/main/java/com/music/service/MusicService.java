package com.music.service;

import java.util.*;

import com.music.dao.MusicDao;
import com.music.entity.Music;



public class MusicService {

	//Insert data to the database
	public static ArrayList<Music> getAllMusicDetails(){
		MusicDao musicdao=new MusicDao();
		ArrayList<Music> listcls=musicdao.fetchAllMusicDetails();
		
		return listcls;
	}
	
//delete data from database
	public ArrayList<Music> delAllclassDetails(){
		MusicDao musicdao=new MusicDao();
		ArrayList<Music> listcls=musicdao.delfetchAllDetails();
		return listcls;
	}
	
	//Update Music Details
	public static ArrayList<Music> UpdateClassDetails(){
		MusicDao musicDao=new MusicDao();
		ArrayList<Music> list=musicDao.updateMusicDetails();
		return list;
		
	}
}
