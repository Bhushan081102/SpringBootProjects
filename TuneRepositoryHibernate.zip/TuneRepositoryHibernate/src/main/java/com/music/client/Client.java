package com.music.client;

import java.util.ArrayList;

import com.music.controller.MusicController;
import com.music.dao.MusicDao;
import com.music.entity.Music;


public class Client {

	public static void main(String[] args) throws Exception {

	//This is for insert the data
//	ArrayList<Music> listmusic=MusicController.fetchAllMusicDetails();
//	
//	for (Music music : listmusic) {
//		System.out.println(music);
//	}
	
	//This is for selecting all the data
	
//	ArrayList<Music> cls=new ArrayList<>();
//	MusicDao.insetData(cls);
	
	
	//This is for data delete
		
//	ArrayList<Music> list=MusicController.delMusicDetailsperId();
//	for (Music music : list) {
//		System.out.println(music);
//	}
		
		ArrayList<Music> list=MusicController.UpdateDataInTable();
		for (Music music : list) {
			System.out.println(music);
		}
}
}
