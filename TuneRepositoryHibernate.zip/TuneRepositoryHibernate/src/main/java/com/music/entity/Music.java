package com.music.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Music {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public int m_id;
	public String m_title;
	public String m_artist;
	public String m_album;
	public int m_year;
	@Override
	public String toString() {
		return "Music [m_id=" + m_id + ", m_title=" + m_title + ", m_artist=" + m_artist + ", m_album=" + m_album
				+ ", m_year=" + m_year + "]";
	}
	
	public Music(int m_id, String m_title, String m_artist, String m_album, int m_year) {
		super();
		this.m_id = m_id;
		this.m_title = m_title;
		this.m_artist = m_artist;
		this.m_album = m_album;
		this.m_year = m_year;
	}
	public Music() {
		// TODO Auto-generated constructor stub
	}

	public int getM_id() {
		return m_id;
	}

	public void setM_id(int m_id) {
		this.m_id = m_id;
	}

	public String getM_title() {
		return m_title;
	}

	public void setM_title(String m_title) {
		this.m_title = m_title;
	}

	public String getM_artist() {
		return m_artist;
	}

	public void setM_artist(String m_artist) {
		this.m_artist = m_artist;
	}

	public String getM_album() {
		return m_album;
	}

	public void setM_album(String m_album) {
		this.m_album = m_album;
	}

	public int getM_year() {
		return m_year;
	}

	public void setM_year(int m_year) {
		this.m_year = m_year;
	}

	public Music(String m_title, String m_artist, String m_album, int m_year) {
		super();
		this.m_title = m_title;
		this.m_artist = m_artist;
		this.m_album = m_album;
		this.m_year = m_year;
	}
	
	
}
